package com.example.myproject;

/*
 * Объект "вопрос"
 */

public class Question {

	public static final int N = 5;
	
	public String name; //сам вопрос в текстовом виде
	public String ans[] = new String [N]; //массив с ответами на этот вопрос
	public int correctAnswer; //номер правильного ответа
	
	//извлекаем вопрос из вопросной строки
	public void AddQuestion(String strQuestion) {
		String str = strQuestion;
		int p = str.indexOf("_");
		this.name = str.substring(0, p);
		for (int i = 0; i < this.N; ++i) {
			this.ans[i] = str.substring(p + 1, str.indexOf("_", p + 1));
			p = str.indexOf("_", p + 1);
		}
		Integer cA = new Integer(str.substring(p + 1));
		this.correctAnswer = (int) (cA);
	}
	
	public Question() {
		
		return;
	}
	
	public Question(String strQuestion) {
		String str = strQuestion;
		int p = str.indexOf("_");
		this.name = str.substring(0, p);
		for (int i = 0; i < this.N; ++i) {
			this.ans[i] = str.substring(p + 1, str.indexOf("_", p + 1));
			p = str.indexOf("_", p + 1);
		}
		Integer cA = new Integer(str.substring(p + 1));
		this.correctAnswer = (int) (cA);
		return;
	}
	
	
	//поставить вопрос
	public void SetQuestion(String str) {
		this.name = str;
	}
	
	//добавить ответы на вопрос с указанием номера правильного ответа
	public void SetAnswer(String[] answer, int corAnswer) {
		for (int i = 0; i < N; ++i)
			this.ans[i] = answer[i];
		this.correctAnswer = corAnswer;
	}
	
}
