package com.example.myproject;

public class GroupQuestions {

	Question[] questions;
	
	public GroupQuestions() {
		
	}
	
	public GroupQuestions(String[] str) {
		
		for (int j = 0; j < 7; ++j) {
			questions[j] = new Question(str[j]);
			/*
			String strQuestion = str[j];
			int p = strQuestion.indexOf("_");
			questions[j].name = strQuestion.substring(0, p);
			for (int i = 0; i < questions[j].N; ++i) {
				questions[j].ans[i] = strQuestion.substring(p + 1, strQuestion.indexOf("_", p + 1));
				p = strQuestion.indexOf("_", p + 1);
			}
			Integer cA = new Integer(strQuestion.substring(p + 1));
			questions[j].correctAnswer = (int) (cA);
			*/
		}
		return;
		/*
		for (int i = 0; i < 7; ++i) {
			this.questions[i].AddQuestion(str[i]);
		}
		*/
	}
	
	//установить группу вопросов
	public void SetGroupQuestions(String[] str) {
		for (int i = 0; i < 7; ++i) {
			this.questions[i].AddQuestion(str[i]);
		}
	}
	
	//отдаёт i-тый вопрос
	public Question GetQuestion(int i) {
		return this.questions[i];
	}
	
}
